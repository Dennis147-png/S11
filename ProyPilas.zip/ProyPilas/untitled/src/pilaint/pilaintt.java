package pilaint;

import javax.swing.*;

public class pilaintt {
    private JPanel Ventana;
    private JTextField textField1;
    private JButton agregarButton;
    private JButton eliminarButton;
    private JButton cimaButton;
    private JTextField textField2;
    private JButton buscarButton;
    private JTextArea textArea1;
}
